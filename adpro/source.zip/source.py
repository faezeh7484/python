import csv
import statistics
from statistics import mean
def calculate_averages(input_file_name,output_file_name):
    with open(input_file_name,'r') as f:
        reader=csv.reader(f)
        nlist=list()
        for row in reader:
            name=row[0]
            grades=row[1:]
            avlist=list()
    
            for grade in grades:
                grade=float(grade)
                avlist.append(grade)
                av=statistics.mean(avlist)
            nlist.append([name,av])
    
        with open(output_file_name,'w',newline='')as outfile:
            writer=csv.writer(outfile)
            for item in nlist:
                writer.writerow(item)
                
def calculate_sorted_averages(input_file_name,output_file_name):
    with open(input_file_name,'r') as f:
        reader=csv.reader(f)
        nlist=list()
        for row in reader:
            name=row[0]
            grades=row[1:]
            gradlist=list()
        
            for grade in grades:
                grade=float(grade)
                gradlist.append(grade)
                av=statistics.mean(gradlist)
            nlist.append([name,av])
        nlist=sorted(nlist,key=lambda item :(item[1],item[0]))
        with open(output_file_name,'w',newline='')as h:
            writer=csv.writer(h)
            for item in nlist:
                writer.writerow(item)


def calculate_three_best(input_file_name,output_file_name):
    with open(input_file_name,'r') as f:
        reader=csv.reader(f)
        nlist=list()
        for row in reader:
            name=row[0]
            grades=row[1:]
            gradlist=list()
        
            for grade in grades:
                grade=float(grade)
                gradlist.append(grade)
                av=statistics.mean(gradlist)
            nlist.append([name,av])
        nlist=sorted(nlist,key=lambda item :(-item[1],item[0]))
        n2list=[nlist[0],nlist[1],nlist[2]]
        with open(output_file_name,'w',newline='')as h:
            writer=csv.writer(h)
            for item in n2list:
                writer.writerow(item)



def calculate_three_worst(input_file_name,output_file_name):
    with open(input_file_name,'r') as f:
        reader=csv.reader(f)
        avlist=list()
    
        for row in reader:
            grades=row[1:]
            gradlist=list()
        
            for grade in grades:
                grade=float(grade)
                gradlist.append(grade)
                av=statistics.mean(gradlist)
            avlist.append(av)
        avlist.sort()
        n=[[avlist[0]],[avlist[1]],[avlist[2]]] 
        with open(output_file_name,'w',newline='' )as h:
            writer=csv.writer(h)
            for item in n:
                writer.writerow(item)

                
                    
def calculate_average_of_averages(input_file_name,output_file_name):
    with open(input_file_name,'r') as f:
        reader=csv.reader(f)
        nlist=list()
        for row in reader:
            grades=row[1:]
            gradlist=list()
        
            for grade in grades:
                grade=float(grade)
                gradlist.append(grade)
                av=statistics.mean(gradlist)
            nlist.append(av)
            avk=statistics.mean(nlist)
            avk=str(avk)
    
    
        with open(output_file_name,'w')as h:
            h.write(avk)
            h.close()
                
