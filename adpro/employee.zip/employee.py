import mysql.connector
user_name=input('please enter your username: ')
password_u=input('please enter your password: ')
database_u=input('please enter your database name: ')
table=input('please enter table name: ')
cnx=mysql.connector.connect(user=user_name,password=password_u,host='127.0.0.1',database=database_u)

cursor=cnx.cursor()
query='select * from %s;'%table
cursor.execute(query)
ghadw=list()
for(Name,Weight,Height)in cursor:
    ghadw.append([Height,Weight,Name])
ghadw1=sorted(ghadw, key=lambda x: (-x[0],x[1]))
print (len(ghadw1))   
for [Height,Weight,Name] in ghadw1:
    print(Name,Height,Weight)



    